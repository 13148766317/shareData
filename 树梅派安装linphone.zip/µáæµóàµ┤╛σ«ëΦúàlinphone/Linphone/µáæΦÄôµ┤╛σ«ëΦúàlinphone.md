树莓派安装linphone

# 树莓派安装linphone

## 目标

安装linphone与手机端h265视频

## 步骤

1.  编译linphone
2.  配置自动应答、账号、摄像头
3.  测试呼叫

## 需求分析

### 编译linphone

参考官方介绍，需要树莓派OS环境下编译；如果能跨平台/Docker环境编译最好了

### 摄像头

无驱；MIC功能

### 网络环境

方便查看树莓派IP或直连

受限于网络环境，方便不了树莓派IP地址，使用如下方式达到电脑与设备直连的效果

1.  手机做热点，开启电脑使用iPhone USB，共享WiFi
2.  树莓派连接电脑WiFi，很快发现192.168.2.3是树莓派IP
3.  ssh pi@192.168.2.3
4.  修改eth0为静态ip `vi /etc/dhcpd.conf`
	```
    interface eth0
    static ip_address=192.168.30.2/24
    ```

## 安装编译环境

`sudo apt install cmake automake autoconf libtool intltool yasm libasound2-dev libpulse-dev libv4l-dev nasm git libglew-dev`

上面的与debian docker中的少了几个，有别于必要的编译环境

```
apt-get install -y alien at autoconf bison ccache clang cmake doxygen elfutils g++ gdb git graphviz intltool libtool lsb-release make nasm ninja-build openssh-client patch python-pip python-pystache python-six yasm 
```

## 下载源码

`git clone https://gitlab.linphone.org/BC/public/linphone-sdk.git --recursive`
之前电脑端已下载SDK，压缩后大小1.15，可以使用，节省下载时间；直连传输速度35MB/s

电脑端执行

```
scp linphone-sdk.zip pi:/home/pi/work/
```

pi端执行

```
cd /home/pi/work
unzip linphone-sdk.zip
```

## 编译

```
cd linphone-sdk
mkdir build-pi && cd build-pi
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF

cmake .. -DLINPHONESDK_PLATFORM=Raspberry -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF

make -j4 
```

出错；发现上面的平台与之前的不一样；按之前的方式，把平台改为Raspberry，再试

```
cmake ..   -DLINPHONESDK_PLATFORM=Raspberry -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF

cmake --build . --parallel 10
```

编译出错

```
CMake Error at toolchains/toolchain-raspberry.cmake:34 (message):
  Define the RASPBIAN_ROOTFS environment variable to point to the raspbian
  rootfs.
Call Stack (most recent call first):
  /usr/share/cmake-3.16/Modules/CMakeDetermineSystem.cmake:93 (include)


CMake Error: CMake was unable to find a build program corresponding to "Unix Makefiles".  CMAKE_MAKE_PROGRAM is not set.  You probably need to select a different build tool.
CMake Error: CMAKE_C_COMPILER not set, after EnableLanguage
CMake Error: CMAKE_CXX_COMPILER not set, after EnableLanguage
```

仔细直需要提取PI交叉编译环境，之前没有配置

## PI交叉编译环境配置

### 下载与安装qemu-arm-static

1.  wget https://github.com/multiarch/qemu-user-static/releases/download/v5.2.0-2/qemu-arm-static
2.  sudo cp qemu-arm-static /usr/bin/
3.  sudo chmod a+x /usr/bin/qemu-arm-static

### 下载 pi 镜像

1.  wget [https://downloads.raspberrypi.org/raspios\_lite\_armhf/images/raspios\_lite\_armhf-2021-01-12/2021-01-11-raspios-buster-armhf-lite.zip](https://downloads.raspberrypi.org/raspios_lite_armhf/images/raspios_lite_armhf-2021-01-12/2021-01-11-raspios-buster-armhf-lite.zip)
2.  解压

### 下载rpi_rootfs

```
git clone https://github.com/kclyu/rpi_rootfs.git
```

执行

```
cd rpi_rootfs
sudo ./build_rootfs.sh create ../2021-01-11-raspios-buster-armhf-lite.img
```

### 安装工具

git clone --progress --verbose https://github.com/raspberrypi/tools.git --depth=1

## 再一次编译
设置环境变量

vi ~/.profile

export RASPBIAN_ROOTFS=/home/pi/work/rpi_rootfs/rootfs

export PATH=/home/pi/work/tools/arm-bcm2708/gcc-linaro-arm-linux-gnueabihf-raspbian-x64/bin:${PATH}

### 版本一

```
cd linphone-sdk
mkdir build-raspberry
cd build-raspberry
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF

make -j4
```

还是出错

```
In file included from /home/pi/work/linphone/external/opus/celt/arm/celt_neon_intr.c:37:
/home/pi/work/linphone/external/opus/celt/arm/celt_neon_intr.c: In function ‘xcorr_kernel_neon_float’:
/usr/lib/gcc/arm-linux-gnueabihf/8/include/arm_neon.h:6740:1: error: inlining failed in call to always_inline ‘vdupq_n_f32’: target specific option mismatch
 vdupq_n_f32 (float32_t __a)
 ^~~~~~~~~~~
 ...
[ 57%] Completed 'EP_xerces'
[ 57%] Built target EP_xerces
make[3]: *** [Makefile:84: all] Error 2
make[2]: *** [CMakeFiles/sdk.dir/build.make:114: sdk-prefix/src/sdk-stamp/sdk-build] Error 2
make[1]: *** [CMakeFiles/Makefile2:76: CMakeFiles/sdk.dir/all] Error 2
make: *** [Makefile:84: all] Error 2
```
搜索到网上也有这个问题[问题](https://www.raspberrypi.org/forums/viewtopic.php?t=28093)

关闭 opus 后编译，冒是可以（-DENABLE_OPUS=OFF）或DCMAKE_C_FLAGS="-mcpu=native -mfpu=auto" 或-mfpu=neon

```
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF -DENABLE_OPUS=OFF
make -j4
``` 
编译成功，不过没有找到linphonec程序，不确定跟关闭单元测试选项有关

再试一下，开启opus与mfpu参数

```
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF -DCMAKE_C_FLAGS="-mcpu=native -mfpu=neon"
make -j4
``` 

去掉 -DENABLE_UNIT_TESTS=OFF -DENABLE_CXX_WRAPPER=OFF,编译成功


```
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF  -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON  -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF -DCMAKE_C_FLAGS="-mcpu=native -mfpu=neon"
make -j4
```

实际可能需要DENABLE_V4L=ON,开启摄像头，开启TOOLS 
```
cmake .. -DLINPHONESDK_PLATFORM=Desktop -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF  -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON  -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF  -DCMAKE_C_FLAGS="-mcpu=native -mfpu=neon" -DENABLE_V4L=ON -DENABLE_CONSOLE_UI=ON -DENABLE_TOOLS=ON

make -j8
```


生成的linphonec执行文件在WORK/desktop/Build/linphone/console目录下

也可以使用 make -j4 -i 编译成功(Ignore errors from recipes.)



### 版本二

```
cd linphone-sdk
mkdir build-pi && cd build-pi

cmake .. -DLINPHONESDK_PLATFORM=Raspberry -DENABLE_OPENH264=ON -DENABLE_WEBRTC_AEC=OFF -DENABLE_UNIT_TESTS=OFF -DENABLE_MKV=OFF -DENABLE_FFMPEG=ON -DENABLE_CXX_WRAPPER=OFF -DENABLE_NON_FREE_CODECS=ON -DENABLE_VCARD=OFF -DENABLE_BV16=OFF -DENABLE_V4L=OFF

cmake --build . --parallel 10
```

出错

```
CMake Error at toolchains/toolchain-raspberry.cmake:34 (message):
  Define the RASPBIAN_ROOTFS environment variable to point to the raspbian
  rootfs.
Call Stack (most recent call first):
  /usr/share/cmake-3.16/Modules/CMakeDetermineSystem.cmake:93 (include)
```
可能平台Raspberry有问题，除了上面碰到的问题外，还提示找不到arm6 gcc，有可能是make config的问题，应该是arm7还是要选择Desktop

## 配置

运行 linphonec 自动应答与视频，可通过-h，查看启动参数

linphonec -C -a

自行编译的版本，提示出错

 ```
./linphonec -C -a
2021-03-24 08:59:49:281 bctbx-error-bctbx_file_open: Error open No such file or directory
2021-03-24 08:59:49:282 liblinphone-error-Unable to open linphone database with uri "/home/pi/.local/share/linphone/linphone.db" and backend Sqlite3
```

#### 手动新建目录
mkdir -p .local/share/linphone


#### 添加账号
proxy add

#### 选择mic
soundcard list
soundcard use

#### 选择摄像头
webcam list
webcam use


### 自动运行 
#### /etc/rc.local 文件添加启动脚本
```
sudo -u pi /home/pi/startlinphone.sh
```
#### 启动脚本
pi@raspberrypi:~/work $ cat startlinphone.sh
```
#!/bin/bash
filelog="/tmp/start.log"
echo "start `date`" >> $filelog
export PATH=/home/pi/work/linphone/build-all/WORK/desktop/Build/linphone/console:$PATH
linphonecsh init -a -C -c /home/pi/.linphonerc -d 6 -l /tmp/log.txt
echo "start finish `date`" >> $filelog
```

## 直接安装二进制
安装的版本比较老，能用
sudo apt install linphone-nogtk
sudo apt remove linphone-nogtk

## 其它问题 

1. 使用下面命令编译通过

```
pi@raspberrypi:~/work/linphone/build-pi $ cmake ..  -DENABLE_OPENH264=ON -DENABLE_NON_FREE_CODECS=ON -DCMAKE_C_FLAGS="-mcpu=native -mfpu=auto" -DENABLE_UNIT_TESTS=NO -DENABLE_OPUS=OFF
```


2. 有编译打印错误 `inlining failed in call to always_inline ‘vld1q_f32’: target specific option mismatch`
	可能是cpu类别不一样，增加-DCMAKE_C_FLAGS="-mcpu=native -mfpu=auto"后还是不样
	可能跟命令行版本有关，可试一下桌面版pi OS编译
	https://www.raspberrypi.org/forums/viewtopic.php?t=280934

3. 显示ortp模块 discarding too old packet
	同步系统时间（重新设置了时区）

4. 显示pulseaudio server failed
	sudo apt-get --purge --reinstall install pulseaudio
	vi /etc/pulse/client.conf
	开启 “; autospawn = yes”

5. pi上呼叫显示 mediastreamer-error-Could not decode base64

6. 前面几秒中有视频，后面没有

7. 录不上音，视频帧率上不去

8. ortp-error-rtp_parse: discarding too old packet
9. 编译版本只有vp8/h264编码库存，如何增加h265或vp9?

## 参考

[Linphone and Raspberry Pi](https://wiki.linphone.org/xwiki/wiki/public/view/Linphone/Linphone%20and%20Raspberry%20Pi/)
[rpi_rootfs](https://github.com/kclyu/rpi_rootfs)
关于gcc编译mfpu选项[GCC compiler optimization for ARM-based systems](https://gist.github.com/fm4dd/c663217935dc17f0fc73c9c81b0aa845)
[Linphone and Raspberry Pi issues](https://github.com/BelledonneCommunications/linphone-sdk/issues/80)

```
I just got my first build to work on Raspberry Pi. I basically turned everything off except for the following. I don't need video so all that is disabled also.

ENABLE_ASSETS
ENABLE_MBEDTLS
ENABLE_SPEEX
ENABLE_SQLITE
ENABLE_SRTP
ENABLE_TOOLS

Then, before you run the build, you need to remove a line about dummy.sh in CMakeFiles/sdk.dir/build.make (around line 75)
(this is my build path)

cd /home/pi/lin_build/linphone-sdk/build-rasp/desktop && /home/pi/lin_build/linphone-sdk/cmake/dummy.sh

That's how I got it to work. Once you do, then you can go back and switch on options one at a time to see which one will break the build.
```